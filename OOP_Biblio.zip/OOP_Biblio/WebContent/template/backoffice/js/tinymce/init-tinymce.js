tinymce.init({
	selector: "textarea.tinymce",
	width: 670,
  	height: 500,
});