package biblio.Model.DAO;
/**
 * @author Patrizio
 *
 */
public interface ImageDAO_Interface {
		
	public static void delete_image(){
		
	}
	
	public static void revisiona() {
	}
}
