package biblio.Model.DAO;

import java.util.List;

import biblio.Model.Opera;
/**
 * @author marco
 *
 */
public interface OperaDAO_Interface {
	
	public static void delete_opera(){
		
	}
	
	public static void pubblica(){
		
	}
	
	public static List<Opera> returnList(){
		return null;
	}
}
