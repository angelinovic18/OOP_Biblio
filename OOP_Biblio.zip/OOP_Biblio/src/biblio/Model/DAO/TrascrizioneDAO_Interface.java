package biblio.Model.DAO;
/**
 * @author MARCO
 *
 */
public interface TrascrizioneDAO_Interface {
	
	
	public static void insert(){
		
	}
	
	public static void valida(){
		
	}
	
	public static void delete(){
		
	}
}
