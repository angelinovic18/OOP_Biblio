package biblio.Model.DAO;

import java.util.List;

import biblio.Model.Utente;
/**
 * @author MARCO
 *
 */
public interface UtenteDAO_Interface {
	
	public static void promuovi_amministratore(){
		
	}
	
	public static void promuovi_avanzato(){
		
	}
	
	public static void promuovi_acquisitore(){
		
	}
	
	public static void promuovi_trascrittore(){
		
	}
	
	public static void promuovi_revisore_a(){
		
	}
	
	public static void promuovi_revisore_t(){
		
	}
	
	public static void elimina_utente(){
		  
	 }
	
	public static int getGroup(){
		return 0;
	}
	
	public static List<Utente> returnListutenti(){
		return null;
	}
	
}
